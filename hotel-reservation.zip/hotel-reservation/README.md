# Simple Hotel Reservation (Java, Console)

A minimal console-based hotel reservation system with basic interactions:

- List rooms
- Check availability by dates and guest count
- Make a reservation
- List reservations
- Cancel a reservation by ID

Dates use ISO format `yyyy-MM-dd` and check-out is exclusive.

## Requirements

- Java 21 (LTS) or later — project has been updated to target Java 21.

## Build (recommended)

This project now includes a `pom.xml` so you can build with Maven and target Java 21.

From the project root (with Java 21 and Maven installed):

```powershell
mvn -e -DskipTests package
```

That will compile the sources and produce a jar under `target/`.

If you prefer the simple javac flow, set your `JAVA_HOME` to a JDK 21 installation and then:

```powershell
javac -d out src/main/java/com/example/hotel/*.java
```

## Run

Run the console app (using compiled classes in `out`):

```powershell
java -cp out com.example.hotel.HotelApp
```

Or run via Maven (exec plugin not included by default):

```powershell
mvn -Dexec.mainClass="com.example.hotel.HotelApp" -Dexec.classpathScope=runtime exec:java
```

## GUI (Swing) Option

A simple Swing UI is also available.

- Compile (same as above):
  ```bash
  javac -d out src/main/java/com/example/hotel/*.java
  ```
- Run GUI:
  ```bash
  java -cp out com.example.hotel.HotelSwingApp
  ```

If using PowerShell and JDK 21, run:

```powershell
java -cp out com.example.hotel.HotelSwingApp
```

---

## Upgrading to Java 21 (notes)

- The project is configured to target Java 21 via `pom.xml` (maven-compiler-plugin release=21 and enforcer rule).
- Install a JDK 21 distribution such as Eclipse Temurin / Adoptium or Oracle JDK. On Windows, download the installer or ZIP and set `JAVA_HOME` to the JDK installation folder.

Example PowerShell to set JAVA_HOME for the current session (adjust path):

```powershell
$env:JAVA_HOME = 'C:\Program Files\Eclipse Adoptium\jdk-21.0.0.\'
$env:Path = "$env:JAVA_HOME\bin;" + $env:Path
java -version
```

If you don't have Maven installed, download and install Maven, or use the Maven Wrapper if added.

If you want me to attempt to install JDK 21 automatically on this machine, tell me and I will try using available tooling (I may need permission or an internet connection).

## Notes

- Data is in-memory and resets each run.
- Sample rooms are preloaded.
