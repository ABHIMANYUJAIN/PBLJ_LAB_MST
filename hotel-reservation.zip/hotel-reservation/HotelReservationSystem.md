# Hotel Reservation System (Java)

A simple hotel reservation system with a console interface and a polished Swing GUI.

## Features

- Rooms catalog with sample data
- Availability search by dates and guest count
- Create reservations with a human-friendly reservation code
- View and cancel reservations
- Swing GUI with improved visuals (tabs, zebra tables, date pickers)

## Reservation Code Format

- Format: `<FirstInitial>-<yyyyMMdd>-<RoomNumber>`
- Example: `A-20251115-102`

## Project Structure

```
hotel-reservation/
├─ src/main/java/com/example/hotel/
│  ├─ Room.java
│  ├─ Reservation.java
│  ├─ Hotel.java
│  ├─ HotelApp.java          # Console app
│  ├─ HotelUI.java           # Swing UI
│  └─ HotelSwingApp.java     # GUI launcher
├─ README.md                 # Quick instructions
└─ HotelReservationSystem.md # This document
```

## Requirements

- Java 11+

## Build

From the project root `hotel-reservation`:

```bash
javac -d out src/main/java/com/example/hotel/*.java
```

## Run (GUI)

```bash
java -cp out com.example.hotel.HotelSwingApp
```

## Run (Console)

```bash
java -cp out com.example.hotel.HotelApp
```

## Usage (GUI)

- Rooms: browse available room types and rates
- Availability: pick dates and guests, click "Check"
- BookNow: enter guest name, set dates/guests, "Find Rooms", pick a room, "Book"
- Bookings: view and cancel by reservation code

## Notes

- Dates are ISO `yyyy-MM-dd`; check-out is exclusive
- All data is in-memory
- GUI aims to match Windows look & feel; Nimbus is the fallback

## Customization

- Change sample room prices/types in `Hotel.seedSampleRooms()`
- Adjust reservation code generation in `Reservation.buildCode()`
- Modify UI labels/text in `HotelUI`
