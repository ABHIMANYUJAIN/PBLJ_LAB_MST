package com.example.hotel;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;

public class Reservation {
    private final String code;
    private final String guestName;
    private final int roomNumber;
    private final LocalDate checkIn;
    private final LocalDate checkOut; // exclusive

    public Reservation(String guestName, int roomNumber, LocalDate checkIn, LocalDate checkOut) {
        this.code = buildCode(guestName, roomNumber, checkIn);
        this.guestName = guestName;
        this.roomNumber = roomNumber;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }

    public String getCode() {
        return code;
    }

    public String getGuestName() {
        return guestName;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public LocalDate getCheckIn() {
        return checkIn;
    }

    public LocalDate getCheckOut() {
        return checkOut;
    }

    public long getNights() {
        return ChronoUnit.DAYS.between(checkIn, checkOut);
    }

    @Override
    public String toString() {
        return "Reservation {" +
                "code='" + code + '\'' +
                ", guest='" + guestName + '\'' +
                ", room=" + roomNumber +
                ", checkIn=" + checkIn +
                ", checkOut=" + checkOut +
                ", nights=" + getNights() +
                '}';
    }

    private static String buildCode(String guestName, int roomNumber, LocalDate checkIn) {
        String g = (guestName == null || guestName.isBlank()) ? "X" : guestName.trim();
        char first = Character.toUpperCase(g.charAt(0));
        String date = checkIn.format(DateTimeFormatter.BASIC_ISO_DATE); // yyyyMMdd
        return first + "-" + date + "-" + roomNumber;
    }
}
