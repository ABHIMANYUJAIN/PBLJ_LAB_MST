package com.example.hotel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.text.NumberFormat;
import java.util.Date;

public class HotelUI extends JFrame {
    private final Hotel hotel;
    private static final NumberFormat CURRENCY = NumberFormat.getCurrencyInstance();
    private static final Color ACCENT = new Color(33, 150, 243);

    // Rooms tab
    private JTable roomsTable;

    // Availability tab
    private JSpinner availCheckIn;
    private JSpinner availCheckOut;
    private JSpinner availGuests;
    private JTable availTable;

    // Make Reservation tab
    private JTextField resGuest;
    private JSpinner resCheckIn;
    private JSpinner resCheckOut;
    private JSpinner resGuests;
    private JComboBox<String> resRoomSelect;

    // Reservations tab
    private JTable reservationsTable;

    public HotelUI(Hotel hotel) {
        super("Hotel Reservation (Swing)");
        this.hotel = hotel;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JLabel heading = new JLabel("Hotel Reservation System", UIManager.getIcon("OptionPane.informationIcon"), SwingConstants.LEADING);
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 20f));
        heading.setForeground(Color.WHITE);
        header.add(heading, BorderLayout.WEST);
        wrapper.add(header, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        tabs.addTab("Rooms", buildRoomsTab());
        tabs.setToolTipTextAt(0, "View all rooms");
        tabs.addTab("Availability", buildAvailabilityTab());
        tabs.setToolTipTextAt(1, "Check available rooms for dates");
        tabs.addTab("BookNow", buildReservationTab());
        tabs.setToolTipTextAt(2, "Create a new reservation");
        tabs.addTab("Bookings", buildReservationsTab());
        tabs.setToolTipTextAt(3, "Manage existing reservations");
        wrapper.add(tabs, BorderLayout.CENTER);
        getContentPane().add(wrapper, BorderLayout.CENTER);

        refreshRooms();
        refreshReservations();
    }

    private JPanel buildRoomsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        roomsTable = new JTable(new DefaultTableModel(new Object[]{"Number", "Type", "Capacity", "Price/night"}, 0) {
            public boolean isCellEditable(int row, int column) {return false;}
        });
        configureTable(roomsTable);
        rightAlignColumn(roomsTable, 0);
        rightAlignColumn(roomsTable, 2);
        currencyColumn(roomsTable, 3);
        panel.add(new JScrollPane(roomsTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildAvailabilityTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        availCheckIn = makeDateSpinner();
        availCheckOut = makeDateSpinner();
        availGuests = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        JButton checkBtn = styledButton("Check");
        checkBtn.addActionListener(e -> doCheckAvailability());
        form.add(new JLabel("Check-in (yyyy-MM-dd):"));
        form.add(availCheckIn);
        form.add(new JLabel("Check-out:"));
        form.add(availCheckOut);
        form.add(new JLabel("Guests:"));
        form.add(availGuests);
        form.add(checkBtn);

        availTable = new JTable(new DefaultTableModel(new Object[]{"Number", "Type", "Capacity", "Price/night"}, 0) {
            public boolean isCellEditable(int row, int column) {return false;}
        });
        configureTable(availTable);
        rightAlignColumn(availTable, 0);
        rightAlignColumn(availTable, 2);
        currencyColumn(availTable, 3);

        panel.add(form, BorderLayout.NORTH);
        panel.add(new JScrollPane(availTable), BorderLayout.CENTER);

        // default dates: today and tomorrow
        LocalDate today = LocalDate.now();
        setSpinnerDate(availCheckIn, today);
        setSpinnerDate(availCheckOut, today.plusDays(1));
        return panel;
    }

    private JPanel buildReservationTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        JPanel form = new JPanel();
        form.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.gridx = 0; gc.gridy = 0; form.add(new JLabel("Guest Name:"), gc);
        gc.gridx = 1; resGuest = new JTextField(15); form.add(resGuest, gc);

        gc.gridx = 0; gc.gridy = 1; form.add(new JLabel("Check-in (yyyy-MM-dd):"), gc);
        gc.gridx = 1; resCheckIn = makeDateSpinner(); form.add(resCheckIn, gc);

        gc.gridx = 0; gc.gridy = 2; form.add(new JLabel("Check-out:"), gc);
        gc.gridx = 1; resCheckOut = makeDateSpinner(); form.add(resCheckOut, gc);

        gc.gridx = 0; gc.gridy = 3; form.add(new JLabel("Guests:"), gc);
        gc.gridx = 1; resGuests = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1)); form.add(resGuests, gc);

        gc.gridx = 0; gc.gridy = 4; form.add(new JLabel("Room:"), gc);
        gc.gridx = 1; resRoomSelect = new JComboBox<>(); resRoomSelect.setEnabled(false); form.add(resRoomSelect, gc);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btns.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 8));
        JButton findRooms = styledButton("Find Rooms");
        findRooms.addActionListener(e -> populateRoomsForReservation());
        JButton book = styledButton("Book");
        book.addActionListener(e -> doBook());
        btns.add(findRooms);
        btns.add(book);

        panel.add(form, BorderLayout.NORTH);
        panel.add(btns, BorderLayout.SOUTH);

        // default dates: today and tomorrow
        LocalDate today = LocalDate.now();
        setSpinnerDate(resCheckIn, today);
        setSpinnerDate(resCheckOut, today.plusDays(1));
        return panel;
    }

    private JPanel buildReservationsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        reservationsTable = new JTable(new DefaultTableModel(new Object[]{"Code", "Guest", "Room", "Check-in", "Check-out", "Nights"}, 0) {
            public boolean isCellEditable(int row, int column) {return false;}
        });
        configureTable(reservationsTable);
        rightAlignColumn(reservationsTable, 2);
        rightAlignColumn(reservationsTable, 5);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 8));
        JButton refresh = styledButton("Refresh");
        refresh.addActionListener(e -> refreshReservations());
        JButton cancel = styledButton("Cancel Selected");
        cancel.addActionListener(e -> doCancelSelected());
        actions.add(refresh);
        actions.add(cancel);

        panel.add(new JScrollPane(reservationsTable), BorderLayout.CENTER);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }

    private void refreshRooms() {
        DefaultTableModel model = (DefaultTableModel) roomsTable.getModel();
        model.setRowCount(0);
        for (Room r : hotel.getRooms()) {
            model.addRow(new Object[]{r.getNumber(), r.getType(), r.getCapacity(), r.getPricePerNight()});
        }
    }

    private void doCheckAvailability() {
        clearError(availCheckIn);
        clearError(availCheckOut);
        LocalDate in = getSpinnerLocalDate(availCheckIn);
        LocalDate out = getSpinnerLocalDate(availCheckOut);
        if (in == null || out == null) {
            setError(availCheckIn);
            setError(availCheckOut);
            JOptionPane.showMessageDialog(this, "Invalid date. Use yyyy-MM-dd", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int guests = (Integer) availGuests.getValue();
        List<Room> avail = hotel.availableRooms(in, out, guests);
        DefaultTableModel model = (DefaultTableModel) availTable.getModel();
        model.setRowCount(0);
        for (Room r : avail) {
            model.addRow(new Object[]{r.getNumber(), r.getType(), r.getCapacity(), r.getPricePerNight()});
        }
        if (avail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No rooms available for those dates.");
        }
    }

    private void populateRoomsForReservation() {
        resRoomSelect.removeAllItems();
        LocalDate in = getSpinnerLocalDate(resCheckIn);
        LocalDate out = getSpinnerLocalDate(resCheckOut);
        if (in == null || out == null) {
            setError(resCheckIn);
            setError(resCheckOut);
            JOptionPane.showMessageDialog(this, "Invalid date. Use yyyy-MM-dd", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!in.isBefore(out)) {
            setError(resCheckIn);
            setError(resCheckOut);
            JOptionPane.showMessageDialog(this, "Check-out must be after check-in.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int guests = (Integer) resGuests.getValue();
        // Validate range
        if (!in.isBefore(out)) {
            setError(resCheckIn);
            setError(resCheckOut);
            JOptionPane.showMessageDialog(this, "Check-out must be after check-in.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        List<Room> avail = hotel.availableRooms(in, out, guests);
        for (Room r : avail) {
            resRoomSelect.addItem(r.getNumber() + " - " + r.getType() + " (₹" + r.getPricePerNight() + ")");
        }
        resRoomSelect.setEnabled(resRoomSelect.getItemCount() > 0);
        if (resRoomSelect.getItemCount() > 0) {
            resRoomSelect.setSelectedIndex(0);
        } else {
            JOptionPane.showMessageDialog(this, "No rooms available. Try different dates or guest count.");
        }
    }

    private void doBook() {
        String guest = resGuest.getText().trim();
        if (guest.isEmpty()) {
            setError(resGuest);
            JOptionPane.showMessageDialog(this, "Guest name required.");
            return;
        }
        clearError(resCheckIn);
        clearError(resCheckOut);
        LocalDate in = getSpinnerLocalDate(resCheckIn);
        LocalDate out = getSpinnerLocalDate(resCheckOut);
        if (in == null || out == null) {
            setError(resCheckIn);
            setError(resCheckOut);
            JOptionPane.showMessageDialog(this, "Invalid date. Use yyyy-MM-dd", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (resRoomSelect.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Select a room (click Find Rooms first).");
            return;
        }
        String selected = (String) resRoomSelect.getSelectedItem();
        int roomNumber;
        try {
            roomNumber = Integer.parseInt(selected.split(" ")[0]);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Could not parse selected room.");
            return;
        }

        Optional<Reservation> res = hotel.book(guest, roomNumber, in, out);
        if (res.isPresent()) {
            Reservation r = res.get();
            JOptionPane.showMessageDialog(this, "Booked! Code: " + r.getCode());
            clearError(resGuest);
            refreshReservations();
        } else {
            JOptionPane.showMessageDialog(this, "Booking failed. Check inputs or availability.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshReservations() {
        DefaultTableModel model = (DefaultTableModel) reservationsTable.getModel();
        model.setRowCount(0);
        for (Reservation r : hotel.getReservations()) {
            model.addRow(new Object[]{r.getCode(), r.getGuestName(), r.getRoomNumber(), r.getCheckIn(), r.getCheckOut(), r.getNights()});
        }
    }

    private void doCancelSelected() {
        int row = reservationsTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a reservation to cancel.");
            return;
        }
        String code = (String) reservationsTable.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Cancel reservation " + code + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean ok = hotel.cancel(code);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Cancelled.");
                refreshReservations();
            } else {
                JOptionPane.showMessageDialog(this, "Cancellation failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void configureTable(JTable table) {
        table.setRowHeight(22);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        // Zebra striping via renderer wrapper
        DefaultTableCellRenderer base = new DefaultTableCellRenderer();
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = base.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground((row % 2 == 0) ? new Color(250, 250, 250) : new Color(238, 238, 238));
                }
                return c;
            }
        });
        ((DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(SwingConstants.LEFT);
    }

    private void rightAlignColumn(JTable table, int idx) {
        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(idx).setCellRenderer(right);
    }

    private void currencyColumn(JTable table, int idx) {
        DefaultTableCellRenderer rend = new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value instanceof Number) {
                    setText(CURRENCY.format(((Number) value).doubleValue()));
                } else {
                    super.setValue(value);
                }
            }
        };
        rend.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(idx).setCellRenderer(rend);
    }

    private JSpinner makeDateSpinner() {
        SpinnerDateModel model = new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner spinner = new JSpinner(model);
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner, "yyyy-MM-dd");
        spinner.setEditor(editor);
        Dimension d = spinner.getPreferredSize();
        d.width = 110;
        spinner.setPreferredSize(d);
        return spinner;
    }

    private void setSpinnerDate(JSpinner spinner, LocalDate date) {
        Date d = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        spinner.setValue(d);
    }

    private LocalDate getSpinnerLocalDate(JSpinner spinner) {
        try {
            Date d = (Date) spinner.getValue();
            return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        } catch (Exception ex) {
            return null;
        }
    }

    private JButton styledButton(String text) {
        JButton b = new JButton(text);
        // Use system LAF defaults to avoid overlay/white issues on Windows
        b.setFocusPainted(false);
        b.setMargin(new Insets(6, 14, 6, 14));
        b.setFont(b.getFont().deriveFont(Font.BOLD));
        return b;
    }

    private void setError(JComponent c) {
        c.putClientProperty("origBorder", c.getBorder());
        c.setBorder(new LineBorder(Color.RED, 2));
        c.setToolTipText("Please correct this field");
    }

    private void clearError(JComponent c) {
        Object orig = c.getClientProperty("origBorder");
        if (orig instanceof Border) {
            c.setBorder((Border) orig);
        }
        c.setToolTipText(null);
    }
}
