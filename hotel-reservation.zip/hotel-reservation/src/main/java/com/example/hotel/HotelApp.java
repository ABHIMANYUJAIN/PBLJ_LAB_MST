package com.example.hotel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class HotelApp {
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Hotel hotel = new Hotel();

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Choose an option: ");
            String option = scanner.nextLine().trim();

            switch (option) {
                case "1":
                    listRooms(hotel);
                    break;
                case "2":
                    checkAvailability(scanner, hotel);
                    break;
                case "3":
                    makeReservation(scanner, hotel);
                    break;
                case "4":
                    listReservations(hotel);
                    break;
                case "5":
                    cancelReservation(scanner, hotel);
                    break;
                case "0":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Try again.\n");
            }
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("=== Hotel Reservation System ===");
        System.out.println("1) List Rooms");
        System.out.println("2) Check Availability");
        System.out.println("3) Make Reservation");
        System.out.println("4) List Reservations");
        System.out.println("5) Cancel Reservation");
        System.out.println("0) Exit");
    }

    private static void listRooms(Hotel hotel) {
        System.out.println("\nRooms:");
        for (Room r : hotel.getRooms()) {
            System.out.println("- " + r);
        }
        System.out.println();
    }

    private static void checkAvailability(Scanner scanner, Hotel hotel) {
        LocalDate checkIn = promptDate(scanner, "Check-in date (yyyy-MM-dd): ");
        LocalDate checkOut = promptDate(scanner, "Check-out date (yyyy-MM-dd): ");
        int guests = promptInt(scanner, "Guests count: ", 1, 20);

        List<Room> avail = hotel.availableRooms(checkIn, checkOut, guests);
        if (avail.isEmpty()) {
            System.out.println("No rooms available for those dates and guest count.\n");
        } else {
            System.out.println("Available rooms:");
            avail.forEach(r -> System.out.println("- " + r));
            System.out.println();
        }
    }

    private static void makeReservation(Scanner scanner, Hotel hotel) {
        String guest = promptNonEmpty(scanner, "Guest name: ");
        LocalDate checkIn = promptDate(scanner, "Check-in date (yyyy-MM-dd): ");
        LocalDate checkOut = promptDate(scanner, "Check-out date (yyyy-MM-dd): ");
        int guests = promptInt(scanner, "Guests count: ", 1, 20);

        List<Room> avail = hotel.availableRooms(checkIn, checkOut, guests);
        if (avail.isEmpty()) {
            System.out.println("No rooms available for those dates and guest count.\n");
            return;
        }
        System.out.println("Choose a room by number from the available list:");
        avail.forEach(r -> System.out.println("- " + r.getNumber() + ": " + r));
        int roomNumber = promptInt(scanner, "Room number: ", 1, 9999);

        Optional<Reservation> res = hotel.book(guest, roomNumber, checkIn, checkOut);
        if (res.isPresent()) {
            Reservation r = res.get();
            double price = avail.stream().filter(x -> x.getNumber() == roomNumber).findFirst().map(Room::getPricePerNight).orElse(0.0);
            double total = price * r.getNights();
            System.out.println("Booked! Reservation Code: " + r.getCode());
            System.out.println("Guest: " + r.getGuestName());
            System.out.println("Room: " + r.getRoomNumber());
            System.out.println("Dates: " + r.getCheckIn() + " to " + r.getCheckOut() + " (" + r.getNights() + " nights)");
            System.out.printf("Total: $%.2f\n\n", total);
        } else {
            System.out.println("Could not make reservation. Check inputs or room availability.\n");
        }
    }

    private static void listReservations(Hotel hotel) {
        if (hotel.getReservations().isEmpty()) {
            System.out.println("No reservations yet.\n");
            return;
        }
        System.out.println("Reservations:");
        hotel.getReservations().forEach(r -> System.out.println("- " + r));
        System.out.println();
    }

    private static void cancelReservation(Scanner scanner, Hotel hotel) {
        if (hotel.getReservations().isEmpty()) {
            System.out.println("No reservations to cancel.\n");
            return;
        }
        System.out.println("Enter Reservation Code to cancel:");
        hotel.getReservations().forEach(r -> System.out.println("- " + r.getCode() + " (Room " + r.getRoomNumber() + ", " + r.getGuestName() + ")"));
        String idStr = scanner.nextLine().trim();
        boolean removed = hotel.cancel(idStr);
        System.out.println(removed ? "Reservation cancelled.\n" : "Reservation not found.\n");
    }

    private static LocalDate promptDate(Scanner scanner, String label) {
        while (true) {
            System.out.print(label);
            String s = scanner.nextLine().trim();
            try {
                LocalDate date = LocalDate.parse(s, DATE_FMT);
                return date;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date. Please use yyyy-MM-dd.");
            }
        }
    }

    private static int promptInt(Scanner scanner, String label, int min, int max) {
        while (true) {
            System.out.print(label);
            String s = scanner.nextLine().trim();
            try {
                int v = Integer.parseInt(s);
                if (v < min || v > max) {
                    System.out.println("Enter a number between " + min + " and " + max + ".");
                } else {
                    return v;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Try again.");
            }
        }
    }

    private static String promptNonEmpty(Scanner scanner, String label) {
        while (true) {
            System.out.print(label);
            String s = scanner.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Cannot be empty. Try again.");
        }
    }
}
