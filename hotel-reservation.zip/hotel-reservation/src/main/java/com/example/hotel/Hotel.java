package com.example.hotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public class Hotel {
    private final List<Room> rooms = new ArrayList<>();
    private final List<Reservation> reservations = new ArrayList<>();

    public Hotel() {
        seedSampleRooms();
    }

    private void seedSampleRooms() {
        rooms.add(new Room(101, "Single", 1299.0, 1));
        rooms.add(new Room(102, "Double", 1999.0, 2));
        rooms.add(new Room(103, "Double", 1999.0, 2));
        rooms.add(new Room(201, "Queen", 3199.0, 3));
        rooms.add(new Room(202, "King", 4599.0, 4));
        rooms.add(new Room(301, "Suite", 5999.0, 5));
    }

    public List<Room> getRooms() {
        return rooms;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public List<Room> availableRooms(LocalDate checkIn, LocalDate checkOut, int guests) {
        return rooms.stream()
                .filter(r -> r.getCapacity() >= guests)
                .filter(r -> isRoomAvailable(r.getNumber(), checkIn, checkOut))
                .collect(Collectors.toList());
    }

    public boolean isRoomAvailable(int roomNumber, LocalDate checkIn, LocalDate checkOut) {
        for (Reservation res : reservations) {
            if (res.getRoomNumber() == roomNumber) {
                if (datesOverlap(checkIn, checkOut, res.getCheckIn(), res.getCheckOut())) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean datesOverlap(LocalDate startA, LocalDate endA, LocalDate startB, LocalDate endB) {
        return !(endA.compareTo(startB) <= 0 || startA.compareTo(endB) >= 0);
    }

    public Optional<Reservation> book(String guestName, int roomNumber, LocalDate checkIn, LocalDate checkOut) {
        Objects.requireNonNull(guestName);
        if (checkIn == null || checkOut == null || !checkIn.isBefore(checkOut)) {
            return Optional.empty();
        }
        if (rooms.stream().noneMatch(r -> r.getNumber() == roomNumber)) {
            return Optional.empty();
        }
        if (!isRoomAvailable(roomNumber, checkIn, checkOut)) {
            return Optional.empty();
        }
        Reservation res = new Reservation(guestName, roomNumber, checkIn, checkOut);
        reservations.add(res);
        return Optional.of(res);
    }

    public boolean cancel(String reservationCode) {
        if (reservationCode == null) return false;
        return reservations.removeIf(r -> reservationCode.equalsIgnoreCase(r.getCode()));
    }
}
