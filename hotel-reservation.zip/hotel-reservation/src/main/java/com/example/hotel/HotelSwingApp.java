package com.example.hotel;

import javax.swing.*;

public class HotelSwingApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                boolean set = false;
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Windows".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        set = true;
                        break;
                    }
                }
                if (!set) {
                    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                        if ("Nimbus".equals(info.getName())) {
                            UIManager.setLookAndFeel(info.getClassName());
                            set = true;
                            break;
                        }
                    }
                }
                if (!set) {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
            } catch (Exception ignored) {}

            HotelUI ui = new HotelUI(new Hotel());
            ui.setVisible(true);
        });
    }
}
