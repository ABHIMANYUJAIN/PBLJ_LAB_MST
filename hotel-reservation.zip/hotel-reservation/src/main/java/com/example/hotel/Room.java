package com.example.hotel;

public class Room {
    private final int number;
    private final String type;
    private final double pricePerNight;
    private final int capacity;

    public Room(int number, String type, double pricePerNight, int capacity) {
        this.number = number;
        this.type = type;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
    }

    public int getNumber() {
        return number;
    }

    public String getType() {
        return type;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return "Room " + number + " (" + type + ", sleeps " + capacity + ", $" + pricePerNight + "/night)";
    }
}
